/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjprimeiraaulapoo1;

/**
 *
 * @author Iftm
 */
import java.util.Scanner;
public class PrjPrimeiraAulaPOO1 {

    public static void main(String[] args) {
        Calculadora c = new Calculadora();
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite o primeiro numero:");
       
                
       float nro1 = sc.nextFloat();
       System.out.print("Digite outro numero:");
       float nro2 = sc.nextFloat();
       
       float resultado = c.somar(nro1, nro2);
       System.out.println("Resultado:"+resultado);
       float resultado2 = c.subtrair(nro1, nro2);
       System.out.println("Resultado:"+resultado2);
       float resultado3 = c.multiplicar(nro1, nro2);
       System.out.println("Resultado:"+resultado3);
       float resultado4 = c.dividir(nro1, nro2);
       System.out.println("Resultado:"+resultado4);
        
        
    
    }
}
