/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjprimeiraaulapoo1;

/**
 *
 * @author Iftm
 */
public class Calculadora {
    
    public float somar(float nro1, float nro2)
    {
       return nro1 + nro2;  
    }
    public float subtrair(float nro1, float nro2){
        return nro1 - nro2;
    }
    public float multiplicar (float nro1,float nro2){
        return nro1 * nro2;
    }
    public float dividir(float nro1, float nro2){
        return nro1 / nro2;
    }
}
